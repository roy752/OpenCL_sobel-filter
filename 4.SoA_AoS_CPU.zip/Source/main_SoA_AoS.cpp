﻿//
//  main_SoA_AoS.cpp
//
//  Written for CSEG437_CSE5437
//  Department of Computer Science and Engineering
//  Copyright © 2021 Sogang University. All rights reserved.
//
#pragma warning(disable: 4996)
#pragma warning(disable: 6386)

#include "Context_SoA_AoS.h"
#include "Config_SoA_AoS.h"

Context context;

__int64 _start, _freq, _end;
float compute_time;

int main(int argc, char* argv[]) 
{
	
    char program_name[] = "Sogang CSEG475_5475 SoA_versus_AoS_20161652";
	int flag = 0;
    fprintf(stdout, "\n###  %s\n\n", program_name);
    fprintf(stdout, "/////////////////////////////////////////////////////////////////////////\n");
    fprintf(stdout, "### INPUT FILE NAME = \t\t%s\n", INPUT_FILE_NAME);
    fprintf(stdout, "### OUTPUT FILE NAME = \t\t%s\n\n", OUTPUT_FILE_NAME);


    read_input_image_from_file32(INPUT_FILE_NAME);   
    prepare_output_image();
	setSobelFilter();
    fprintf(stdout, "### IMAGE OPERATION = ");
	switch (IMAGE_OPERATION)
	{
	case SO_NAIVE:
	{
		fprintf(stdout, "Sobel filter naive on GPU\n");
		fprintf(stdout, "/////////////////////////////////////////////////////////////////////////\n\n");
		prepare_SoA_input_and_output();
		convert_to_greyscale_image_SoA_CPU_to_temporal();
		flag = initialize_OpenCL();
		if (flag) break;
		flag = set_local_work_size_and_kernel_arguments_naive();
		if (flag) break;
		flag = run_OpenCL_kernel();
		if (flag) break;
		fprintf(stdout, "/////////////////////////////////////////////////////////////////////////\n\n");
		convert_SoA_output_to_output_image_data();
		write_output_image_to_file32(OUTPUT_FILE_NAME);

		cleanup();
		break;
	}
	case SO_OPT:
	{
		fprintf(stdout, "Sobel filter optimized on GPU\n");
		fprintf(stdout, "/////////////////////////////////////////////////////////////////////////\n\n");
		prepare_SoA_input_and_output();
		convert_to_greyscale_image_SoA_CPU_to_temporal();
		flag = initialize_OpenCL();
		if (flag) break;
		flag = set_local_work_size_and_kernel_arguments_naive();
		if (flag) break;
		flag = run_OpenCL_kernel();
		if (flag) break;
		fprintf(stdout, "/////////////////////////////////////////////////////////////////////////\n\n");
		convert_SoA_output_to_output_image_data();
		write_output_image_to_file32(OUTPUT_FILE_NAME);

		cleanup();
		break;
	}
	default:
	{
		fprintf(stdout, "^^^ Nothing has been done!\n");
		fprintf(stdout, "/////////////////////////////////////////////////////////////////////////\n\n");
		break;
	}
	}
	return flag;
}