﻿#include "Context_SoA_AoS.h"
#include "Config_SoA_AoS.h"

void convert_to_greyscale_image_SoA_CPU(void) {
    for (unsigned int i = 0; i < context.image_width * context.image_height; i++) {

        BYTE intensity = BYTE(0.299f * context.SoA_image_input.R_plane[i]  // R
            + 0.587f * context.SoA_image_input.G_plane[i]  // G
            + 0.114f * context.SoA_image_input.B_plane[i]);  // B
        context.SoA_image_output.R_plane[i] = intensity;
        context.SoA_image_output.G_plane[i] = intensity;
        context.SoA_image_output.B_plane[i] = intensity;
        context.SoA_image_output.A_plane[i] = context.SoA_image_input.A_plane[i];
    }
}

void convert_to_greyscale_image_AoS_CPU(void) {
    Pixel_Channels* tmp_ptr_input = context.AoS_image_input;
    Pixel_Channels* tmp_ptr_output = context.AoS_image_output;
    for (unsigned int i = 0; i < context.image_width * context.image_height; i++) {
        BYTE intensity = BYTE(0.299f * tmp_ptr_input->R // R
            + 0.587f * tmp_ptr_input->G  // G
            + 0.114f * tmp_ptr_input->B);  // B
        tmp_ptr_output->R = intensity;
        tmp_ptr_output->G = intensity;
        tmp_ptr_output->B = intensity;
        tmp_ptr_output->A = tmp_ptr_input->A;

        tmp_ptr_input++; tmp_ptr_output++;
    }
}

void convert_to_greyscale_image_SoA_CPU_to_temporal(void)
{
	for (unsigned int i = 0; i < context.image_width * context.image_height; i++) {

		BYTE intensity = BYTE(0.299f * context.SoA_image_input.R_plane[i]  // R
			+ 0.587f * context.SoA_image_input.G_plane[i]  // G
			+ 0.114f * context.SoA_image_input.B_plane[i]);  // B
		context.SoA_image_temporal_output.R_plane[i] = intensity;
		context.SoA_image_temporal_output.G_plane[i] = intensity;
		context.SoA_image_temporal_output.B_plane[i] = intensity;
		context.SoA_image_temporal_output.A_plane[i] = context.SoA_image_input.A_plane[i];
	}
}

void convert_to_greyscale_image_AoS_CPU_to_temporal(void)
{
	Pixel_Channels* tmp_ptr_input = context.AoS_image_input;
	Pixel_Channels* tmp_ptr_output = context.AoS_image_temporal_output;
	for (unsigned int i = 0; i < context.image_width * context.image_height; i++) {
		BYTE intensity = BYTE(0.299f * tmp_ptr_input->R // R
			+ 0.587f * tmp_ptr_input->G  // G
			+ 0.114f * tmp_ptr_input->B);  // B
		tmp_ptr_output->R = intensity;
		tmp_ptr_output->G = intensity;
		tmp_ptr_output->B = intensity;
		tmp_ptr_output->A = tmp_ptr_input->A;

		tmp_ptr_input++; tmp_ptr_output++;
	}
}

void apply_sobel_filter_SoA_CPU(void)
{
	int sobel_filter_column[9] = { 1,2,1,0,0,0,-1,-2,-1 };
	int sobel_filter_row[9] = { 1,0,-1,2,0,-2,1,0,-1 };
	auto& buffer = context.SoA_image_temporal_output;
	int width = (int)context.image_width;
	int height = (int)context.image_height;
	for (int i = 0; i < height; ++i)
	{
		for (int j = 0; j < width; ++j)
		{

			int list[9][2] = { {i - 1,j - 1},{i - 1,j},{i - 1,j + 1},{i,j - 1},{i,j},{i,j + 1}, {i + 1,j - 1},{i + 1,j},{i + 1,j + 1} };
			for (int k = 0; k < 9; ++k) list[k][0] = clamp(0, height-1, list[k][0]), list[k][1] = clamp(0, width-1, list[k][1]);
			int GxInt = 0, GyInt = 0, dummy = 0;
			for (int k = 0; k < 9; ++k)
			{
				GxInt += sobel_filter_row[k] * buffer.R_plane[list[k][0] * context.image_width + list[k][1]];
				GyInt += sobel_filter_column[k] * buffer.G_plane[list[k][0] * context.image_width + list[k][1]];
				dummy += buffer.B_plane[list[k][0] * context.image_width + list[k][1]];
			}
			float Gx = GxInt / 1020.0, Gy = GyInt / 1020.0;
			//float G = sqrtf(Gx * Gx + Gy * Gy) / sqrtf(2);
			float G = 2.0f*sqrt(Gx * Gx + Gy * Gy);
			BYTE ans = clamp(0x00, 0xff, G * 255.0f);
			context.SoA_image_output.R_plane[i * width + j] = ans;
			context.SoA_image_output.G_plane[i * width + j] = ans;
			context.SoA_image_output.B_plane[i * width + j] = ans;
			context.SoA_image_output.A_plane[i * width + j] = buffer.A_plane[i * width + j];
		}
	}
}

void apply_sobel_filter_AoS_CPU(void)
{
	int sobel_filter_column[9] = { 1,2,1,0,0,0,-1,-2,-1 };
	int sobel_filter_row[9] = { 1,0,-1,2,0,-2,1,0,-1 };
	auto& buffer = context.AoS_image_temporal_output;
	int width = (int)context.image_width;
	int height = (int)context.image_height;
	for (int i = 0; i < height; ++i)
	{
		for (int j = 0; j < width; ++j)
		{

			int list[9][2] = { {i - 1,j - 1},{i - 1,j},{i - 1,j + 1},{i,j - 1},{i,j},{i,j + 1}, {i + 1,j - 1},{i + 1,j},{i + 1,j + 1} };
			for (int k = 0; k < 9; ++k) list[k][0] = clamp(0, height-1, list[k][0]), list[k][1] = clamp(0, width-1, list[k][1]);
			int GxInt = 0, GyInt = 0, dummy = 0;
			for (int k = 0; k < 9; ++k)
			{
				GxInt += sobel_filter_row[k] * buffer[list[k][0] * context.image_width + list[k][1]].R;
				GyInt += sobel_filter_column[k] * buffer[list[k][0] * context.image_width + list[k][1]].G;
				dummy += buffer[list[k][0] * context.image_width + list[k][1]].B;
			}
			float Gx = GxInt / 1020.0, Gy = GyInt / 1020.0;
			float G = 2.0f*sqrt(Gx * Gx + Gy * Gy);
			BYTE ans= clamp(0x00, 0xff, G * 255.0f);
			context.AoS_image_output[i * width + j].R = ans;
			context.AoS_image_output[i * width + j].G = ans;
			context.AoS_image_output[i * width + j].B = ans;
			context.AoS_image_output[i * width + j].A = buffer[i * width + j].A;
		}
	}
}

int initialize_OpenCL(void)
{
	//platform 가져오기
	cl_int errcode_ret;
	auto& now = context.cl_stuff;
	errcode_ret = clGetPlatformIDs(1, &now.platform_id, NULL);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;

	// GPU 가져오기
	errcode_ret = clGetDeviceIDs(now.platform_id, CL_DEVICE_TYPE_GPU, 1, &now.device_id, NULL);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	
	//context 만들기
	now.context = clCreateContext(NULL, 1, &now.device_id, NULL, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;

	//GPU의 command Queue 만들기
	const cl_queue_properties properties[3] = {CL_QUEUE_PROPERTIES, CL_QUEUE_PROFILING_ENABLE, 0};//CL_QUEUE_PROFILING_ENABLE;
	
	now.cmd_queue = clCreateCommandQueueWithProperties(now.context, now.device_id,
		properties, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	
	//OpenCL C source code로 program 만들기
	now.prog_src.length = read_kernel_from_file(OPENCL_C_PROG_FILE_NAME, &now.prog_src.string);
	now.program = clCreateProgramWithSource(now.context, 1, (const char**)&now.prog_src.string, &now.prog_src.length, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;

	// program build 하기. 현재 OpenCL 3.0
	const char options[] = "-cl-std=CL3.0";
	errcode_ret = clBuildProgram(now.program, 1, &now.device_id, options, NULL, NULL);
	if (errcode_ret != CL_SUCCESS)
	{
		print_build_log(now.program, now.device_id, "GPU");
		return 1;
	}

	//kernel 만들기
	now.kernel = clCreateKernel(now.program, KERNEL_NAME, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;

	//input, output buffer 만들고 데이터 옮기기

	now.input_R_plane = clCreateBuffer(now.context, CL_MEM_READ_ONLY, sizeof(BYTE) * context.image_width * context.image_height, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	now.input_G_plane = clCreateBuffer(now.context, CL_MEM_READ_ONLY, sizeof(BYTE) * context.image_width * context.image_height, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	now.input_B_plane = clCreateBuffer(now.context, CL_MEM_READ_ONLY, sizeof(BYTE) * context.image_width * context.image_height, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	now.input_A_plane = clCreateBuffer(now.context, CL_MEM_READ_ONLY, sizeof(BYTE) * context.image_width * context.image_height, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	now.output_R_plane = clCreateBuffer(now.context, CL_MEM_WRITE_ONLY, sizeof(BYTE) * context.image_width * context.image_height, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	now.output_G_plane = clCreateBuffer(now.context, CL_MEM_WRITE_ONLY, sizeof(BYTE) * context.image_width * context.image_height, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	now.output_B_plane = clCreateBuffer(now.context, CL_MEM_WRITE_ONLY, sizeof(BYTE) * context.image_width * context.image_height, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	now.output_A_plane = clCreateBuffer(now.context, CL_MEM_WRITE_ONLY, sizeof(BYTE) * context.image_width * context.image_height, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	now.BO_filter_x = clCreateBuffer(now.context, CL_MEM_READ_ONLY,
		sizeof(int) * 25, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	now.BO_filter_y = clCreateBuffer(now.context, CL_MEM_READ_ONLY,
		sizeof(int) * 25, NULL, &errcode_ret);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;

	errcode_ret = clEnqueueWriteBuffer(now.cmd_queue, now.input_R_plane, CL_FALSE, 0,
		sizeof(BYTE) * context.image_width * context.image_height, context.SoA_image_temporal_output.R_plane, 0, NULL, NULL);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	errcode_ret = clEnqueueWriteBuffer(now.cmd_queue, now.input_G_plane, CL_FALSE, 0,
		sizeof(BYTE) * context.image_width * context.image_height, context.SoA_image_temporal_output.G_plane, 0, NULL, NULL);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	errcode_ret = clEnqueueWriteBuffer(now.cmd_queue, now.input_B_plane, CL_FALSE, 0,
		sizeof(BYTE) * context.image_width * context.image_height, context.SoA_image_temporal_output.B_plane, 0, NULL, NULL);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	errcode_ret = clEnqueueWriteBuffer(now.cmd_queue, now.input_A_plane, CL_FALSE, 0,
		sizeof(BYTE) * context.image_width * context.image_height, context.SoA_image_temporal_output.A_plane, 0, NULL, NULL);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	errcode_ret = clEnqueueWriteBuffer(now.cmd_queue, now.BO_filter_x, CL_FALSE, 0,
		sizeof(int) * 25, context.sobel_filter_row, 0, NULL, NULL);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	errcode_ret = clEnqueueWriteBuffer(now.cmd_queue, now.BO_filter_y, CL_FALSE, 0,
		sizeof(int) * 25, context.sobel_filter_column, 0, NULL, NULL);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;


	clFinish(now.cmd_queue);
	return 0;
}


int set_local_work_size_and_kernel_arguments_naive()
{
	auto& now = context.cl_stuff;
	now.global_work_size[0] = context.image_width;
	now.global_work_size[1] = context.image_height;

	now.local_work_size[0] = LOCAL_WORK_SIZE_0;
	now.local_work_size[1] = LOCAL_WORK_SIZE_1;

	cl_int errcode_ret;

	errcode_ret = clSetKernelArg(now.kernel, 0, sizeof(cl_mem), &now.input_R_plane);
	errcode_ret |= clSetKernelArg(now.kernel, 1, sizeof(cl_mem), &now.input_G_plane);
	errcode_ret |= clSetKernelArg(now.kernel, 2, sizeof(cl_mem), &now.input_B_plane);
	errcode_ret |= clSetKernelArg(now.kernel, 3, sizeof(cl_mem), &now.input_A_plane);

	errcode_ret |= clSetKernelArg(now.kernel, 4, sizeof(cl_mem), &now.output_R_plane);
	errcode_ret |= clSetKernelArg(now.kernel, 5, sizeof(cl_mem), &now.output_G_plane);
	errcode_ret |= clSetKernelArg(now.kernel, 6, sizeof(cl_mem), &now.output_B_plane);
	errcode_ret |= clSetKernelArg(now.kernel, 7, sizeof(cl_mem), &now.output_A_plane);

	errcode_ret |= clSetKernelArg(now.kernel, 8, sizeof(cl_mem), &now.BO_filter_x);
	errcode_ret |= clSetKernelArg(now.kernel, 9, sizeof(cl_mem), &now.BO_filter_y);

	errcode_ret |= clSetKernelArg(now.kernel, 10, sizeof(int), &context.image_width);
	errcode_ret |= clSetKernelArg(now.kernel, 11, sizeof(int), &context.image_height);

#if IMAGE_OPERATION == SO_OPT
	
	size_t local_mem_size = sizeof(cl_uchar) * (LOCAL_WORK_SIZE_0 + 4) * (LOCAL_WORK_SIZE_1 + 4);
	errcode_ret |= clSetKernelArg(now.kernel, 12, local_mem_size, NULL);
	errcode_ret |= clSetKernelArg(now.kernel, 13, local_mem_size, NULL);
	errcode_ret |= clSetKernelArg(now.kernel, 14, local_mem_size, NULL);
	errcode_ret |= clSetKernelArg(now.kernel, 15, local_mem_size, NULL);
#endif
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	return 0;
}



int run_OpenCL_kernel()
{
	
	cl_int errcode_ret;

	util_reset_event_time();

	auto& now = context.cl_stuff;

	// 커널 실행하기
	//왐-압
	errcode_ret = clEnqueueNDRangeKernel(now.cmd_queue, now.kernel, 2, NULL,
		now.global_work_size, now.local_work_size, 0, NULL, &now.event_for_timing);
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;
	clWaitForEvents(1, &now.event_for_timing);
	for (int i = 0; i < N_EXECUTIONS; i++) {
		errcode_ret = clEnqueueNDRangeKernel(now.cmd_queue, now.kernel, 2, NULL,
			now.global_work_size, now.local_work_size, 0, NULL, &now.event_for_timing);
		if (CHECK_ERROR_CODE(errcode_ret)) return 1;
		clWaitForEvents(1, &now.event_for_timing);
		if (CHECK_ERROR_CODE(errcode_ret)) return 1;
		util_accumulate_event_times_1_2(now.event_for_timing);
	}
	
	util_print_accumulated_device_time_1_2(N_EXECUTIONS);
	
	/* GPU에서 CPU로 데이터 옮기기. */
	
	
	errcode_ret = clEnqueueReadBuffer(now.cmd_queue, now.output_R_plane, CL_TRUE, 0,
		sizeof(BYTE) * context.image_width * context.image_height, context.SoA_image_output.R_plane, 0, NULL,
		&now.event_for_timing);
	errcode_ret = clEnqueueReadBuffer(now.cmd_queue, now.output_G_plane, CL_TRUE, 0,
		sizeof(BYTE) * context.image_width * context.image_height, context.SoA_image_output.G_plane, 0, NULL,
		&now.event_for_timing);
	errcode_ret = clEnqueueReadBuffer(now.cmd_queue, now.output_B_plane, CL_TRUE, 0,
		sizeof(BYTE) * context.image_width * context.image_height, context.SoA_image_output.B_plane, 0, NULL,
		&now.event_for_timing);
	errcode_ret = clEnqueueReadBuffer(now.cmd_queue, now.output_A_plane, CL_TRUE, 0,
		sizeof(BYTE) * context.image_width * context.image_height, context.SoA_image_output.A_plane, 0, NULL,
		&now.event_for_timing);
	
	
	if (CHECK_ERROR_CODE(errcode_ret)) return 1;

	return 0;
}



void setSobelFilter(void)
{
	int tmp[25] = { -5,-8,-10,-8,-5,-4,-10,-20,-10,-4, 0, 0, 0, 0, 0,4, 10, 20, 10, 4,5, 8, 10, 8, 5 };
	int tmp2[25] = { -5,-4,0,4,5,-8,-10,0,10,8,-10,-20,0,20,10,-8,-10,0,10,8,-5,-4,0,4,5 };
	std::copy(std::begin(tmp), std::end(tmp),context.sobel_filter_column);
	std::copy(std::begin(tmp2), std::end(tmp2), context.sobel_filter_row);
}




template<typename T,typename S>
T clamp(T mn, T mx, S value)
{
	return (T)max(mn, min(mx, value));
}

void cleanup(void)
{
	
	//CPU 쪽 memory free
	if (context.AoS_image_input != NULL) free(context.AoS_image_input);
	if (context.AoS_image_output != NULL) free(context.AoS_image_output);
	if (context.AoS_image_temporal_output != NULL) free(context.AoS_image_temporal_output);
	if (context.SoA_image_input.R_plane != NULL) free(context.SoA_image_input.R_plane);
	if (context.SoA_image_input.G_plane != NULL) free(context.SoA_image_input.G_plane);
	if (context.SoA_image_input.B_plane != NULL) free(context.SoA_image_input.B_plane);
	if (context.SoA_image_input.A_plane != NULL) free(context.SoA_image_input.A_plane);
	if (context.SoA_image_output.R_plane != NULL) free(context.SoA_image_output.R_plane);
	if (context.SoA_image_output.G_plane != NULL) free(context.SoA_image_output.G_plane);
	if (context.SoA_image_output.B_plane != NULL) free(context.SoA_image_output.B_plane);
	if (context.SoA_image_output.A_plane != NULL) free(context.SoA_image_output.A_plane);
	if (context.SoA_image_temporal_output.R_plane != NULL) free(context.SoA_image_temporal_output.R_plane);
	if (context.SoA_image_temporal_output.G_plane != NULL) free(context.SoA_image_temporal_output.G_plane);
	if (context.SoA_image_temporal_output.B_plane != NULL) free(context.SoA_image_temporal_output.B_plane);
	if (context.SoA_image_temporal_output.A_plane != NULL) free(context.SoA_image_temporal_output.A_plane);

	//GPU쪽 memory free
	auto& now = context.cl_stuff;
	if (now.prog_src.string) free(now.prog_src.string);
	if (now.input_RGBA) clReleaseMemObject(now.input_RGBA);
	if (now.output_RGBA) clReleaseMemObject(now.output_RGBA);
	if (now.input_R_plane) clReleaseMemObject(now.input_R_plane);
	if (now.input_G_plane) clReleaseMemObject(now.input_G_plane);
	if (now.input_B_plane) clReleaseMemObject(now.input_B_plane);
	if (now.input_A_plane) clReleaseMemObject(now.input_A_plane);
	if (now.output_R_plane) clReleaseMemObject(now.output_R_plane);
	if (now.output_G_plane) clReleaseMemObject(now.output_G_plane);
	if (now.output_B_plane) clReleaseMemObject(now.output_B_plane);
	if (now.output_A_plane) clReleaseMemObject(now.output_A_plane);
	if (now.BO_filter_x) clReleaseMemObject(now.BO_filter_x);
	if (now.BO_filter_y) clReleaseMemObject(now.BO_filter_y);
	if (now.kernel) clReleaseKernel(now.kernel);
	if (now.program) clReleaseProgram(now.program);
	if (now.cmd_queue) clReleaseCommandQueue(now.cmd_queue);
	if (now.device_id) clReleaseDevice(now.device_id);
	if (now.context) clReleaseContext(now.context);
	if (now.event_for_timing) clReleaseEvent(now.event_for_timing);
}